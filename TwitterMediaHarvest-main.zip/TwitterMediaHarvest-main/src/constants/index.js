export const DEFAULT_DIRECTORY = process.env.NODE_ENV === 'production' ? 'twitter_media_harvest' : 'mh-dev'
