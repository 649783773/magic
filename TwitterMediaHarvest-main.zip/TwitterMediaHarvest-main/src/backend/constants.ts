export const DEFAULT_DIRECTORY = 'twitter_media_harvest'
